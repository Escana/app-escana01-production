export const globalStyles = () => {}

