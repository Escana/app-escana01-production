"use client"

import DocumentScanner from "@/app/components/document-scanner"

export default function ScanPage() {
  return <DocumentScanner />
}

