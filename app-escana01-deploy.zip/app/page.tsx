import SimpleDashboard from "@/components/SimpleDashboard"

export default function HomePage() {
  return <SimpleDashboard />
}
